package com.example.text;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button speak,volUp,VolDown;
    SeekBar pitchSB,SpeedSB;
    TextToSpeech textToSpeech;
    EditText speechtxt;
    AudioManager audioManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        speak = findViewById(R.id.button);
        volUp = findViewById(R.id.button2);
        VolDown = findViewById(R.id.button3);
        pitchSB = findViewById(R.id.seekBar);
        SpeedSB = findViewById(R.id.seekBar2);
        speechtxt = findViewById(R.id.editTextTextPersonName);
        AudioManager audioManager = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if(i==TextToSpeech.SUCCESS)
                {
                    int avail = textToSpeech.isLanguageAvailable(Locale.UK);
                    if(avail!=TextToSpeech.LANG_NOT_SUPPORTED)
                    {
                        speak.setEnabled(true);
                    }
                    else
                    {
                        speak.setEnabled(false);
                    }
                }
            }
        });
        speak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                speak();

            }
        });
        VolDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audioManager.adjustVolume(AudioManager.ADJUST_LOWER,AudioManager.FLAG_PLAY_SOUND);
            }
        });
        volUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audioManager.adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_PLAY_SOUND);
            }
        });
    }

    private void speak() {
        String speech = speechtxt.getText().toString();
        float pitch = pitchSB.getProgress()/50;
        float speed = pitchSB.getProgress()/50;
        if(pitch<0.1) pitch = 0.1f;
        if(speed<0.1) pitch = 0.1f;
        textToSpeech.setPitch(pitch);
        textToSpeech.setSpeechRate(speed);
        textToSpeech.speak(speech,TextToSpeech.QUEUE_FLUSH,null,null);
    }
    protected void onDestroy() {
        if(textToSpeech!=null)
        {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}